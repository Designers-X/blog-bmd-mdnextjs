import React from 'react';
import Styles from 'components/ShopPage/TopSellingProduct/Style.module.scss';

function RightsideSmallBanner() {
  return (
    <div>
      <div className={Styles.MainImgFive}>
        <img src="/package/MainImg5.png" />
      </div>
    </div>
  );
}

export default RightsideSmallBanner;
